
local lx, _M = oo{
    _cls_ = '',
    _ext_ = 'seeder'
}

local app, lf, tb, str, new = lx.kit()

local Model = lx.use('model')
local use = lx.ns('.app.model')

local fair = lx.h.fair

function _M:run()

end

return _M

