
return function(fair)
    
    local lx = require('lxlib')
    local app, lf, tb, str, new = lx.kit()
    local use = lx.ns('.app.model')
    local User = use(
        'user'
    )

    local rand = lf.rand

    fair:define(User, function(faker)
        
        return {
            name = faker:name(),
            email = faker:email(),
            password = Hash('123456'),
            remember_token = str.random(10)
        }
    end)

end

