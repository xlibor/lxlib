
return function(route)

    route:get('/', function(c)

        c:view('welcome')
    end)
end
 
