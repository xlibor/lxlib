
return function(schedule)
    
    schedule:command('app/test'):every(5)
end

