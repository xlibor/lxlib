
return function(route)
    
    route:add('test', function(c)
        c:json{status = 1, msg = 'hello lxlib'}
    end)
end