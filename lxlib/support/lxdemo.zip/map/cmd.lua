
return function(cmd)

    cmd:add('app/test', 'test@index')
end