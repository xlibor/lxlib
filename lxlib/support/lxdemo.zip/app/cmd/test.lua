
local lx, _M = oo{
    _cls_ = '',
    _ext_ = 'command'
}

local app, lf, tb, str = lx.kit()
 
function _M:index()

    self:info('hello lxer')

    local user = Db('users'):first()
    echo(user)
end

return _M

