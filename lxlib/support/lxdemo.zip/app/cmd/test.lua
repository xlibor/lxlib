
local lx, _M = oo{
    _cls_ = '',
    _ext_ = 'command'
}

local app, lf, tb, str = lx.kit()
 
function _M:index()

    self:info('hello lxer')
end

return _M

