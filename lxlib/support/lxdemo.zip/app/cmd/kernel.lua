
local _M = {
    _cls_ = '',
    _ext_ = {
        path = 'lxlib.console.kernel'
    }
}

local lx = require('lxlib')

function _M:loadCommands(cmder)

    cmder:group('.app.cmd', function()
        require('.map.cmd')(cmder)
    end)
end

return _M

