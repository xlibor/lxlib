
local lx, _M = oo{
    _cls_ = '',
    _ext_ = 'lxlib.http.bar.verifyCsrfToken'
}

function _M:ctor()

    self.except = {}
end

return _M

