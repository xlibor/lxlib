 
local _M = {
    _cls_ = '',
    _ext_ = {
        path = 'lxlib.routing.controller'
    },
    _mix_ = {'validateRequest'}
}

return _M

