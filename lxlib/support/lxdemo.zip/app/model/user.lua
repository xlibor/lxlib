
local lx, _M = oo{
    _cls_ = '',
    _ext_ = 'model',
    _mix_ = {'authenticatable', 'authorizable', 'canResetPassword'}
}

local app, lf, tb, str = lx.kit()

function _M:ctor()

    self.table = 'users'
end

function _M:boot()

end

return _M

