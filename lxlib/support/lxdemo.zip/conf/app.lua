
local lx = require('lxlib')
local env = lx.env

local conf = {
    key              = env('appKey'),
    namespace        = '.app.http.ctler',
    debug            = true,
    bondCheck        = env('bondCheck', true),
    scopeCheck       = env('scopeCheck', true),
    locale           = 'en',
    fallbackLocale   = 'en',

    boxes = {
        'lxlib.auth.authBox',
        'lxlib.cookie.cookieBox',
        'lxlib.session.sessionBox',
        'lxlib.cache.cacheBox',
        'lxlib.db.dbBox',
        'lxlib.redis.redisBox',
        'lxlib.view.viewBox',
        'lxlib.log.logBox',
        'lxlib.validation.validationBox',
        'lxlib.translation.translationBox',
        'lxlib.pagination.paginationBox',
        'lxlib.net.netBox',
        'lxlib.hash.hashBox',
        'lxlib.crypt.cryptBox',
        '.app.box.routeBox',
        '.app.box.appBox',
        '.app.box.dbBox'
    },

    faces = {
        Auth         = 'auth',
        Cache        = 'cache@get',
        Conf         = 'config.col@get',
        Cookie       = 'cookie',
        Crypt        = 'crypt',
        Db           = 'db@table',
        Event        = 'events',
        Fs           = {'files', 'exists', true},
        Gate         = 'gate',
        Hash         = 'hash@make',
        Lang         = 'translator',
        Log          = 'logger',
        Redis        = 'redis',
        Req          = 'request@input',
        Resp         = 'response',
        Route        = 'router',
        Session      = 'session.store@get',
        Validator    = 'validator',
        View         = 'view',
        Schema       = 'db.schema',
    }
}

return conf

