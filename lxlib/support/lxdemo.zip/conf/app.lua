
local lx = require('lxlib')
local env = lx.env

local conf = {
    key                 = env('appKey'),
    namespace           = '.app.http.ctler',
    debug               = true,
    bondCheck           = env('bondCheck', true),
    scopeCheck          = env('scopeCheck', true),
    locale              = 'en',
    fallbackLocale      = 'en',
    timezone            = env('timezone') or 'Asia/Shanghai',

    boxes = {
        'lxlib.auth.authBox',
        'lxlib.cookie.cookieBox',
        'lxlib.session.sessionBox',
        'lxlib.cache.cacheBox',
        'lxlib.db.dbBox',
        'lxlib.redis.redisBox',
        'lxlib.view.viewBox',
        'lxlib.log.logBox',
        'lxlib.validation.validationBox',
        'lxlib.translation.translationBox',
        'lxlib.pagination.paginationBox',
        'lxlib.net.netBox',
        'lxlib.hash.hashBox',
        'lxlib.dt.dtBox',
        'lxlib.crypt.cryptBox',
        'lxlib.ext.flash.flashBox',
        'lxlib.ext.socialite.socialiteBox',
        'lxlib.ext.image.imageBox',
        '.app.box.routeBox',
        '.app.box.appBox',
        '.app.box.dbBox'
    },

    faces = {
        App         = 'app',
        Auth        = 'auth',
        Cache       = 'cache@get',
        Conf        = 'config@get',
        Cookie      = 'cookie',
        Crypt       = 'crypt',
        Db          = 'db@table',
        Dt          = 'datetime',
        Event       = 'events',
        Flash       = 'flash',
        Fs          = {'files', nil, true},
        Gate        = 'gate',
        Hash        = 'hash@make',
        Img         = 'image',
        Lang        = 'translator',
        Log         = 'logger',
        Redis       = 'redis',
        Req         = 'request',
        Resp        = 'response',
        Route       = 'router',
        Session     = 'session.store@get',
        Socialite   = 'socialite',
        Url         = 'url',
        Validator   = 'validator',
        View        = 'view',
        Schema      = 'db.schema',

    }
}

return conf

